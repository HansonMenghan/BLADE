#' BLADE
#' @title BLADE-Coal.prob.func
#'
#' @description BLADE-Coal.prob.func
#'
#' @details
#'
#' @param Tree Tree
#' @param Y.dist.mat Y.dist.mat
#' @param X.dist.mat X.dist.mat
#' @param phylo.cor.mat phylo.cor.mat
#' @param geo.cor.mat geo.cor.mat
#' @param iter iter
#' @import igraph
#' @import ape
#' @import dplyr
#' @import tibble
#' @return a list
#'
#' @examples
#' \dontrun{
#' Coal.prob.func <- function(Tree, Y.dist.mat = NULL, X.dist.mat = NULL, phylo.cor.mat = NULL, geo.cor.mat = NULL, iter = 5000, warmup = 0.9)
#' }
#' @export

Coal.prob.func <- function(Tree, Y.dist.mat = NULL, X.dist.mat = NULL, phylo.cor.mat = NULL, geo.cor.mat = NULL, iter = 5000, warmup = 0.9){
  node_df <- as_tibble(Tree) %>% select(node, posterior) %>% filter(!is.na(posterior))
  Tree <- as.phylo(Tree)
  Topology <- data.frame(Tree$edge, Tree$edge.length) %>%
    rename_all(.funs = function(i)c("From", "To", "Length")) %>%
    arrange(To)
  To.name <- c(Tree$tip.label, Topology$To[-c(1:length(Tree$tip.label))])
  Topology <- Topology %>% mutate(To = To.name) %>% merge(., node_df, by.x = "From", by.y = "node") %>% rename(Prob = "posterior")
  graph <- graph_from_data_frame(Topology[,1:2])
  Anc.prob.mat <- matrix(0, nrow = length(Tree$tip.label), ncol = length(Tree$tip.label))
  colnames(Anc.prob.mat) <- rownames(Anc.prob.mat) <- Tree$tip.label
  for (i in 1:(nrow(Anc.prob.mat)-1)){
    for (j in (i+1):ncol(Anc.prob.mat)){
      print(c(i,j))
      a <- bfs(graph, colnames(Anc.prob.mat)[i], neimode="in", unreachable=FALSE, order=TRUE, dist=TRUE)$dist
      a <- a[!is.nan(a)]
      b <- bfs(graph, colnames(Anc.prob.mat)[j], neimode="in", unreachable=FALSE, order=TRUE, dist=TRUE)$dist
      b <- b[!is.nan(b)]
      intersect <- intersect(names(a),names(b))
      anc <- a[intersect]
      MRCA <- names(anc)[which.min(anc)]
      Anc.prob.mat[i,j] <- Topology %>% filter(From == MRCA) %>% dplyr::select(Prob) %>% unlist() %>% unique()
    }
  }

  if (!is.null(Y.dist.mat)){
    LMM.rlt <- LMM.func(Y.dist = Y.dist.mat, PC.num = 2, X.dist.mat, Phy.id = rep(1:nrow(Y.dist.mat)), Spatial.id = rep(1:nrow(Y.dist.mat)), phylo.cor.mat, geo.cor.mat, iter = iter, warmup = warmup)
    R2 <- LMM.rlt$R2_full[2]
    mean.tree.prob <- Topology %>% filter(!(duplicated(From))) %>% summarise(mean = mean(Prob)) %>% unlist()
    coal.prob.coef <- R2
  }else{
    coal.prob.coef <- 1
    LMM.rlt <- NULL
  }
  Anc.prob.mat <- t(Anc.prob.mat) + Anc.prob.mat
  diag(Anc.prob.mat) <- 1
  Adm.prob.mat <- 1-Anc.prob.mat*coal.prob.coef
  return(list(Adm.prob.mat = Adm.prob.mat))
}



