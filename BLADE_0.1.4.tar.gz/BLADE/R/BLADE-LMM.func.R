#' BLADE
#' @title BLADE-LMM.func
#'
#' @description BLADE-LMM.func
#'
#' @details
#'
#' @param Y.dist Y.dist
#' @param PC.num PC.num
#' @param X.dist X.dist
#' @param Phy.id Phy.id
#' @param Spatial.id Spatial.id
#' @param phy.cov.matrix phy.cov.matrix
#' @param spatial.cov.matrix spatial.cov.matrix
#' @param iter iter
#' @param warmup warmup
#' @param chains chains
#' @param seed seed
#' @import rstan
#' @import dplyr
#' @import tibble
#' @return a list
#'
#' @examples
#' \dontrun{
#' LMM.func(Y.dist, PC.num = 2, X.dist = NULL, Phy.id, Spatial.id, phy.cov.matrix, spatial.cov.matrix, iter = 5000, warmup = 0.95, chains = 1, seed = 0)
#' }
#' @export

LMM.func <- function(Y.dist, PC.num = 2, X.dist = NULL, Phy.id, Spatial.id, phy.cov.matrix, spatial.cov.matrix, iter = 5000, warmup = 0.95, chains = 1, seed = 0) {
  ################# prepare rstan data
  pcoa.rlt <- cmdscale(Y.dist, k = PC.num, eig = T)
  Y.dat <- pcoa.rlt$points
  weight <- (pcoa.rlt$eig[1:PC.num] / sum(pcoa.rlt$eig[1:PC.num]))
  if (is.null(X.dist)) {
    X.dat <- data.frame(rep(1, nrow(Y.dat)))
  } else {
    X.dat <- cmdscale(X.dist, k = nrow(X.dist) - 1)
  }
  if (is.null(spatial.cov.matrix)) {
    spatial.cov.matrix <- diag(rep(1, nrow(Y.dist)))
  }
  phy.cov.matrix.scale <- phy.cov.matrix / max(phy.cov.matrix)
  spatial.cov.matrix.scale <- spatial.cov.matrix / max(spatial.cov.matrix)
  ################ define stan code ###############
  lmm_stan_code <- "
data {
  int<lower = 1> N;
  int<lower = 1> K;
  int<lower = 1> J_phy;
  int<lower = 1> J_spatial;
  int<lower = 1, upper = J_phy> group_phy[N];
  int<lower = 1, upper = J_spatial> group_spatial[N];
  matrix[N, K] X;
  vector[N] y;
  cov_matrix[J_phy] prior_phy_Sigma;
  cov_matrix[J_spatial] prior_spatial_Sigma;
}

parameters {
  vector[K] beta;
  vector[J_phy] u_phy;
  vector[J_spatial] u_spatial;
  real<lower=0> sigma;
}

transformed parameters {
  cov_matrix[J_phy] scaled_prior_phy_Sigma = sigma * prior_phy_Sigma;
  cov_matrix[J_spatial] scaled_prior_spatial_Sigma = sigma * prior_spatial_Sigma;
}

model {
  beta ~ normal(0, 1);
  sigma ~ normal(0, 1);
  u_phy ~ multi_normal(rep_vector(0, J_phy), scaled_prior_phy_Sigma);
  u_spatial ~ multi_normal(rep_vector(0, J_spatial), scaled_prior_spatial_Sigma);
  y ~ normal(X * beta + u_phy + u_spatial, sigma);
}

generated quantities {
  vector[N] log_lik;
  for (n in 1:N){
  log_lik[n] = normal_lpdf(y[n] | X[n] * beta + u_phy[group_phy[n]] + u_spatial[group_spatial[n]], sigma);
  }
}"
  stan_model <- stan_model(model_code = lmm_stan_code)
  stan_data.list <- lapply(as.data.frame(Y.dat), function(i) {
    stan_data <- list(
      N = length(i),
      K = ncol(X.dat),
      J_phy = length(unique(Phy.id)),
      J_spatial = length(unique(Spatial.id)),
      group_phy = Phy.id,
      group_spatial = Spatial.id,
      X = X.dat,
      y = i,
      prior_phy_Sigma = phy.cov.matrix,
      prior_spatial_Sigma = spatial.cov.matrix
    )
  })
  # run model
  stan.fit.rlt.list <- lapply(stan_data.list, function(i) {
    fit <- sampling(
      stan_model,
      data = i,
      iter = iter,
      warmup = ceiling(iter * warmup),
      chains = chains,
      seed = seed,
      control = list(adapt_delta = 0.99, max_treedepth = 15)
    )
  })
  # extract coefficient
  coef.rlt.list <- lapply(1:length(stan.fit.rlt.list), function(i) {
    fit <- stan.fit.rlt.list[[i]]
    stan_data <- stan_data.list[[i]]
    beta_dist <- rstan::extract(fit, "beta")$beta
    u_phy_dist <- rstan::extract(fit, "u_phy")$u_phy
    u_spatial_dist <- rstan::extract(fit, "u_spatial")$u_spatial
    log_lik <- extract(fit, "log_lik")$log_lik
    phy_design.matrix <- model.matrix(~ 0 + factor(stan_data$group_phy, levels = unique(stan_data$group_phy)))
    spatial_design.matrix <- model.matrix(~ 0 + factor(stan_data$group_spatial, levels = unique(stan_data$group_spatial)))
    # estimate R2
    X.effect <- as.matrix(stan_data$X) %*% t(beta_dist)
    phy.effect <- phy_design.matrix %*% t(u_phy_dist)
    spatial.effect <- spatial_design.matrix %*% t(u_spatial_dist)
    random.effect <- stan_data$y %*% t(rep(1, ncol(X.effect))) - X.effect - phy.effect - spatial.effect
    effect.list <- list(X.effect = X.effect, phy.effect = phy.effect, spatial.effect = spatial.effect, random.effect = random.effect)
    Total.var <- do.call("cbind", lapply(effect.list, function(i) apply(i, 2, var)))
    R2_dist <- diag(1 / rowSums(Total.var)) %*% Total.var
    colnames(R2_dist) <- gsub("effect", "R2", colnames(R2_dist))
    R2_est <- colMeans(R2_dist)
    return(list(R2_est = R2_est, log_lik = log_lik))
  })
  R2_est.mat <- do.call("cbind", lapply(coef.rlt.list, function(i) i$R2_est))
  R2_full <- as.vector(R2_est.mat %*% weight)
  return(list(stan.fit.rlt.list = stan.fit.rlt.list, coef.rlt.list = coef.rlt.list, R2_full = R2_full))
}
