#' BLADE
#' @title BLADE-F3.admixture.func
#'
#' @description BLADE-F3.admixture.func
#'
#' @details
#'
#' @param data data
#' @param coord coord
#' @param group.name group.name
#' @param sig sig
#' @param method method
#' @param resample.n resample.n
#' @import dplyr
#' @import reshape2
#' @import tibble
#' @import igraph
#' @import kernlab
#' @import MASS
#' @import sf
#' @return a list
#'
#' @examples
#' \dontrun{
#' F3.admixture.func(data, coord, group.name = "Language family", sig = F, method = "bootstrap", resample.n = 1000)
#' }
#' @export

F3.admixture.func <- function(data, coord = NULL, group.name = "Language family", sig = F, method = "bootstrap", resample.n = 1000) {
  select <- dplyr::select
  freq <- data %>%
    group_by(!!sym(group.name)) %>%
    summarise_all(.funs = mean) %>%
    column_to_rownames(group.name)
  F3.func <- function(Target, Source1, Source2) {
    sum((Target - Source1) * (Target - Source2)) / length(Source2)
  }
  F3.iter.func <- function(freq) {
    triple.dat <- expand.grid(rownames(freq), rownames(freq), rownames(freq)) %>%
      filter(Var1 != Var2 & Var1 != Var3 & Var2 != Var3)
    triple.dat <- triple.dat %>%
      mutate(index = sapply(1:nrow(triple.dat), function(i) paste(c(triple.dat[i, "Var1"], sort(c(triple.dat[i, "Var2"], triple.dat[i, "Var3"]))), collapse = "|"))) %>%
      filter(!duplicated(index)) %>%
      select(!index)
    F3.value <- sapply(1:nrow(triple.dat), function(i) {
      F3.func(freq[triple.dat[i, 1], ], freq[triple.dat[i, 2], ], freq[triple.dat[i, 3], ])
    })
    F3.dat <- cbind(triple.dat, f3 = F3.value)
  }
  F3.dat <- F3.iter.func(freq)

  if (!is.null(coord)) {
    data.coord <- cbind(data, coord)
    point.sf <- st_as_sf(data.coord, coords = colnames(coord))
    hulls <- point.sf %>%
      group_by(!!!sym(group.name)) %>%
      summarise(geometry = st_union(geometry)) %>%
      st_convex_hull()
    overlap.mat <- do.call("rbind", lapply(1:nrow(hulls), function(i) {
      sapply(1:nrow(hulls), function(j) {
        as.numeric(st_intersects(hulls$geometry[i], hulls$geometry[j]))
      })
    }))
    rownames(overlap.mat) <- colnames(overlap.mat) <- hulls[[group.name]]
    overlap.mat[is.na(overlap.mat)] <- 0
    diag(overlap.mat) <- 0
    geo.constraint.tripple <- do.call("rbind", lapply(rownames(overlap.mat), function(i) {
      adj.group <- colnames(overlap.mat)[overlap.mat[i, ] > 0]
      geo.constraint.dat <- tryCatch(
        {
          cbind(i, expand.grid(adj.group, adj.group)) %>% rename_all(.funs = function(i) c("Var1", "Var2", "Var3"))
        },
        error = function(i) NULL
      )
    }))
  } else {
    overlap.mat <- diag(rep(1, length(unique(unlist(data[, group.name])))))
    rownames(overlap.mat) <- colnames(overlap.mat) <- unlist(unique(data[, group.name]))
    geo.constraint.tripple <- expand.grid(rownames(overlap.mat), rownames(overlap.mat), rownames(overlap.mat))
  }

  if (isTRUE(sig)) {
    set.seed(0)
    if (method == "bootstrap") {
      freq.resample.list <- lapply(1:resample.n, function(i) {
        print(paste0(i, "/", resample.n))
        freq.resample <- data %>%
          group_by(!!sym(group.name)) %>%
          sample_n(size = n(), replace = T) %>%
          summarise_all(.funs = mean) %>%
          column_to_rownames(group.name)
        F3.dat.resample <- F3.iter.func(freq.resample) %>% rename(!!paste0("f3|", i) := "f3")
      })
      trait.cluster.list <- NULL
    }
    if (method == "jackknife") {
      compute_eigengap <- function(data, max_k = 50, sigma = 1, nn = 10) {
        dist_matrix <- as.matrix(dist(data))
        similarity_matrix <- exp(-dist_matrix^2 / (2 * sigma^2))
        n <- nrow(data)
        adjacency_matrix <- matrix(0, n, n)
        for (i in 1:n) {
          neighbors <- order(dist_matrix[i, ])[2:(nn + 1)]
          adjacency_matrix[i, neighbors] <- similarity_matrix[i, neighbors]
          adjacency_matrix[neighbors, i] <- similarity_matrix[neighbors, i]
        }
        degree_matrix <- diag(rowSums(adjacency_matrix))
        laplacian <- degree_matrix - adjacency_matrix
        normalized_laplacian <- ginv(sqrt(degree_matrix)) %*%
          laplacian %*% ginv(sqrt(degree_matrix))
        eig_values <- eigen(normalized_laplacian,
          symmetric = TRUE,
          only.values = TRUE
        )$values
        eig_values <- sort(eig_values)
        eig_gaps <- diff(eig_values[1:(max_k + 1)])
        optimal_k <- which.max(eig_gaps)
        return(list(
          eigenvalues = eig_values,
          gaps = eig_gaps,
          optimal_k = optimal_k,
          normalized_laplacian = normalized_laplacian
        ))
      }
      eigengap.rlt <- compute_eigengap(t(data %>% select(!group.name)), max_k = ncol(data) - 1)
      specc.rlt <- NULL
      k <- 0
      while (is.null(specc.rlt)) {
        specc.rlt <- tryCatch(
          {
            specc(t(data %>% select(!group.name)), centers = eigengap.rlt$optimal_k - k)
          },
          error = function(i) NULL
        )
        k <- k + 1
      }
      trait.cluster.list <- data.frame(trait.name = colnames(data %>% select(!group.name)), cluster.index = specc.rlt@.Data) %>%
        group_split(cluster.index) %>%
        lapply(., function(i) i$trait.name)
      freq.resample.list <- lapply(1:length(trait.cluster.list), function(i) {
        print(paste0(i, "/", length(trait.cluster.list)))
        freq.resample <- data %>%
          dplyr::select(!(trait.cluster.list[[i]])) %>%
          group_by(!!sym(group.name)) %>%
          sample_n(size = n(), replace = T) %>%
          summarise_all(.funs = mean) %>%
          column_to_rownames(group.name)
        F3.dat.resample <- F3.iter.func(freq.resample) %>% rename(!!paste0("f3|", i) := "f3")
      })
    }
    freq.resample.dat <- Reduce(function(x, y) merge(x, y, id.vars = c("Var1", "Var2", "Var3")), c(list(F3.dat), freq.resample.list))
    p.value <- sapply(1:nrow(freq.resample.dat), function(i) {
      dist <- (freq.resample.dat %>% select(contains("|")))[i, ] %>% unlist()
      p.value <- wilcox.test(dist, 0, alternative = "less")$p.value
    })
    freq.summary.dat <- cbind(freq.resample.dat[, 1:4], freq.resample.dat %>% rowwise() %>%
      transmute(
        row_mean = mean(c_across(contains("|")), na.rm = TRUE),
        row_sd = sd(c_across(contains("|")), na.rm = TRUE),
        row_se = sd(c_across(contains("|")), na.rm = TRUE) / sqrt(ncol(freq.resample.dat) - 4)
      ) %>% ungroup() %>% mutate(z.score = row_mean / row_se), p.value = round(p.value, 4))
    freq.summary.geo.constraint.dat <- merge(freq.summary.dat, geo.constraint.tripple, by = c("Var1", "Var2", "Var3"))
    admixture.direc <- matrix(0, nrow = length((rownames(freq))), ncol = length((rownames(freq))))
    admixture.direc.weak <- matrix(0, nrow = length((rownames(freq))), ncol = length((rownames(freq))))
    colnames(admixture.direc) <- rownames(admixture.direc) <- rownames(freq)
    colnames(admixture.direc.weak) <- rownames(admixture.direc.weak) <- rownames(freq)
    for (i in 1:nrow(freq.summary.geo.constraint.dat)) {
      if (unlist(freq.summary.geo.constraint.dat[i, "f3"]) < 0 & unlist(freq.summary.geo.constraint.dat[i, "p.value"]) < 0.05) {
        var1.name <- unlist(freq.summary.geo.constraint.dat[i, "Var1"])
        var2.name <- unlist(freq.summary.geo.constraint.dat[i, "Var2"])
        var3.name <- unlist(freq.summary.geo.constraint.dat[i, "Var3"])
        admixture.direc[c(var2.name, var3.name), var1.name] <- 1
      }
      if (method == "jackknife" &
        unlist(freq.summary.geo.constraint.dat[i, "f3"]) < 0 &
        unlist(freq.summary.geo.constraint.dat[i, "p.value"]) >= 0.05 &
        unlist(freq.summary.geo.constraint.dat[i, "p.value"]) < 0.1) {
        var1.name <- unlist(freq.summary.geo.constraint.dat[i, "Var1"])
        var2.name <- unlist(freq.summary.geo.constraint.dat[i, "Var2"])
        var3.name <- unlist(freq.summary.geo.constraint.dat[i, "Var3"])
        if (admixture.direc[var2.name, var1.name] == 0) admixture.direc.weak[var2.name, var1.name] <- 1
        if (admixture.direc[var3.name, var1.name] == 0) admixture.direc.weak[var3.name, var1.name] <- 1
      }
    }
    edge.style.mat <- matrix("none", nrow = nrow(admixture.direc), ncol = ncol(admixture.direc))
    rownames(edge.style.mat) <- rownames(admixture.direc)
    colnames(edge.style.mat) <- colnames(admixture.direc)
    edge.style.mat[admixture.direc.weak == 1] <- "dashed"
    edge.style.mat[admixture.direc == 1] <- "solid"
    admixture.plot.mat <- (admixture.direc + admixture.direc.weak) > 0
    g <- graph_from_adjacency_matrix(admixture.plot.mat * 1, mode = "directed")
    if (ecount(g) > 0) {
      edge.ends <- ends(g, E(g), names = TRUE)
      edge.style.vec <- mapply(function(from, to) edge.style.mat[from, to], edge.ends[, 1], edge.ends[, 2])
      E(g)$lty <- edge.style.vec
      E(g)$width <- ifelse(edge.style.vec == "dashed", 1.5, 2)
    }
    plot(g)
    return(list(freq = freq, freq.summary.dat = freq.summary.dat, freq.resample.dat = freq.resample.dat, freq.summary.geo.constraint.dat = freq.summary.geo.constraint.dat, admixture.direc = admixture.direc, trait.cluster.list = trait.cluster.list))
  } else {
    admixture.direc <- matrix(0, nrow = length((rownames(freq))), ncol = length((rownames(freq))))
    colnames(admixture.direc) <- rownames(admixture.direc) <- rownames(freq)
    overlap.mat <- overlap.mat[match(rownames(admixture.direc), rownames(overlap.mat)), match(colnames(admixture.direc), colnames(overlap.mat))]
    admixture.direc <- admixture.direc * overlap.mat
    for (i in 1:nrow(F3.dat)) {
      if (unlist(F3.dat[i, "f3"]) < 0) {
        var1.name <- unlist(F3.dat[i, "Var1"])
        var2.name <- unlist(F3.dat[i, "Var2"])
        var3.name <- unlist(F3.dat[i, "Var3"])
        admixture.direc[c(var2.name, var3.name), var1.name] <- 1
      }
    }
    plot(graph_from_adjacency_matrix(admixture.direc))
    return(list(freq = freq, F3.dat = F3.dat, admixture.direc = admixture.direc, trait.cluster.list = trait.cluster.list))
  }
}
