#' BLADE
#' @title BLADE-mcmc.admixture
#'
#' @description BLADE-mcmc.admixture
#'
#' @details
#'
#' @param Y Y
#' @param X X
#' @param mcmc.n mcmc.n
#' @param prob.not.co.mat prob.not.co.mat
#' @param burn.in burn.in
#' @param chains chains
#' @param seed seed
#' @import rstan
#' @import dplyr
#' @import tibble
#' @import MASS
#' @return a list
#'
#' @examples
#' \dontrun{
#' mcmc.admixture(Y, X, mcmc.n = 20000, prob.not.co.mat = NULL, burn.in = 0.95, chains = 1, seed = 0)
#' }
#' @export

mcmc.admixture <- function(Y, X, mcmc.n = 20000, prob.not.co.mat = NULL, burn.in = 0.95, chains = 1, seed = 0) {
  X.name <- colnames(X)
  X <- sapply(1:ncol(X), function(i) {
    lm(X[, i] ~ X[, -i])$residuals
  })
  colnames(X) <- X.name
  if (is.null(prob.not.co.mat)) {
    prob.not.co.mat <- diag(1, nrow = ncol(X), ncol = ncol(X))
  }
  X <- X %*% ginv(prob.not.co.mat)
  stan_data <- list(
    N = length(Y),
    K = ncol(X),
    X = X,
    y = Y
  )

  lm_stan_code <- "
data {
  int<lower = 1> N;
  int<lower = 1> K;
  matrix[N, K] X;
  vector[N] y;
}

parameters {
  vector[K] beta;
  real<lower=0> sigma;
}

model {
  beta ~ uniform(0, 10);
  sigma ~ normal(0, 1);
  y ~ normal(X * beta, sigma);
}

generated quantities {
  vector[N] log_lik;
  for (n in 1:N){
  log_lik[n] = normal_lpdf(y[n] | X[n] * beta, sigma);
  }
}"
  stan_model <- stan_model(model_code = lm_stan_code)
  fit <- sampling(
    stan_model,
    data = stan_data,
    iter = mcmc.n,
    warmup = ceiling(mcmc.n * burn.in),
    chains = chains,
    seed = seed,
    control = list(adapt_delta = 0.99, max_treedepth = 15)
  )
  beta_dist <- rstan::extract(fit, "beta")$beta
  colnames(beta_dist) <- X.name
  return(beta_dist)
}
