#' BLADE
#' @title BLADE-subgroup.wasserstein.func
#'
#' @description BLADE-subgroup.wasserstein.func
#'
#' @details
#'
#' @param df df
#' @param lon_col lon_col
#' @param lat_col lat_col
#' @param subgroup_col subgroup_col
#' @param crs_proj crs_proj
#' @import dplyr
#' @import reshape2
#' @import tibble
#' @import transport
#' @import sf
#' @return a list
#'
#' @examples
#' \dontrun{
#' subgroup.wasserstein.func(df, lon_col = "Longitude", lat_col = "Latitude", subgroup_col = "Subgroup", crs_proj = 3857)
#' }
#' @export

subgroup.wasserstein.func <- function(df, lon_col = "Longitude", lat_col = "Latitude", subgroup_col = "Subgroup", crs_proj = 3857) {
  # 1. Convert (lon, lat) to projected coordinates (X, Y)
  df_sf <- st_as_sf(
    df,
    coords = c(lon_col, lat_col),
    crs = 4326 # input is in WGS84 lon/lat
  ) |>
    st_transform(crs_proj)

  coords <- st_coordinates(df_sf)
  df_xy <- df |>
    mutate(
      X = coords[, "X"],
      Y = coords[, "Y"]
    )

  # 2. Build a list of coordinate matrices for each subgroup
  subgroups <- sort(unique(df_xy[[subgroup_col]]))
  n <- length(subgroups)

  coords_list <- lapply(subgroups, function(sg) {
    as.matrix(
      df_xy |>
        filter(.data[[subgroup_col]] == sg) |>
        select(X, Y)
    )
  })
  names(coords_list) <- subgroups

  # 3. Initialize an empty distance matrix
  D <- matrix(0,
    nrow = n, ncol = n,
    dimnames = list(subgroups, subgroups)
  )

  # 4. Pairwise Wasserstein distances between subgroups
  for (i in seq_len(n)) {
    for (j in seq_len(i - 1)) {
      a <- coords_list[[i]] # coordinates of subgroup i: (na x 2)
      b <- coords_list[[j]] # coordinates of subgroup j: (nb x 2)

      na <- nrow(a)
      nb <- nrow(b)

      # Uniform weights within each subgroup (can be changed later)
      w_a <- rep(1 / na, na)
      w_b <- rep(1 / nb, nb)

      # Compute pairwise Euclidean distances between all points in a and b
      full_dist <- as.matrix(dist(rbind(a, b))) # (na + nb) x (na + nb)
      costm <- full_dist[1:na, (na + 1):(na + nb), drop = FALSE]

      # 1-Wasserstein (Earth Mover's Distance) given the ground cost matrix
      d_ij <- wasserstein(
        w_a, w_b,
        costm = costm,
        p = 1
      )

      D[i, j] <- D[j, i] <- d_ij
    }
  }

  attr(D, "unit") <- "meters"
  return(D)
}
