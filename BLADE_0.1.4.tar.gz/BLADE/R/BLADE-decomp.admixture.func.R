#' BLADE
#' @title BLADE-decomp.admixture.func
#'
#' @description BLADE-decomp.admixture.func
#'
#' @details
#'
#' @param freq.dat freq.dat
#' @param Y.name Y.name
#' @param X.name X.name
#' @param mcmc.n mcmc.n
#' @param col col
#' @param test test
#' @param prob.not.co.mat prob.not.co.mat
#' @param burn.in burn.in
#' @import rstan
#' @import dplyr
#' @import tibble
#' @import ggplot2
#' @return a list
#'
#' @examples
#' \dontrun{
#' decomp.admixture.func(freq.dat,
#'   Y.name = "Sinitic", X.name = c("Hmong_Mien", "Turkic", "Tungusic"),
#'   mcmc.n = 50000, col = c(
#'     "#BF3EFF", "#FF523F", "#8B6508", "#7D7D7D", "#00CED1", "#8B0000", "#246b93", "#006400", "#CD1076", "#9EdD4E", "#FF3030", "#FFA500",
#'     "#ed1299", "#09f9f5", "#53868B", "#cc8e12", "#d561dd", "#c93f00", "#ddd53e",
#'     "#4aef7b", "#e86502", "#39ba30", "#e07233"
#'   ), test = "wilcox.test", prob.not.co.mat = NULL, burn.in = 0.5
#' )
#' }
#' @export

decomp.admixture.func <- function(freq.dat, Y.name = "Sinitic", X.name = c("Hmong_Mien", "Turkic", "Tungusic"),
                                  mcmc.n = 50000, col = c(
                                    "#BF3EFF", "#FF523F", "#8B6508", "#7D7D7D", "#00CED1", "#8B0000", "#246b93", "#006400", "#CD1076", "#9EdD4E", "#FF3030", "#FFA500",
                                    "#ed1299", "#09f9f5", "#53868B", "#cc8e12", "#d561dd", "#c93f00", "#ddd53e",
                                    "#4aef7b", "#e86502", "#39ba30", "#e07233"
                                  ), test = "wilcox.test", prob.not.co.mat = NULL, burn.in = 0.5) {
  mix.dat <- t(freq.dat)
  Y <- mix.dat[, Y.name]
  X <- mix.dat[, X.name]
  n.beta <- ncol(X)
  if (is.null(prob.not.co.mat)) {
    prob <- NULL
  } else {
    prob <- diag(prob.not.co.mat[Y.name, X.name])
  }
  mcmc.fit <- mcmc.admixture(Y, X, mcmc.n = mcmc.n, prob.not.co.mat = prob, burn.in = burn.in)
  burn.left <- mcmc.fit
  burn.left.scale <- burn.left
  burn.left.scale[, 1:n.beta] <- t(apply(burn.left[, 1:n.beta], 1, function(i) i / sum(i)))

  parm.mean <- colMeans(burn.left.scale)
  CI <- burn.left.scale %>%
    as_tibble() %>%
    summarise_all(.funs = function(i) {
      lower <- quantile(i, 0.025)
      higher <- quantile(i, 0.975)
      CI <- c(lower, higher)
      names(CI) <- c("2.5%", "97.5%")
      return(CI)
    })

  SD <- burn.left.scale %>%
    as_tibble() %>%
    summarise_all(.funs = function(i) {
      sd <- sd(i, na.rm = T)
      return(sd)
    })

  admixture.prop <- parm.mean[1:ncol(X)]
  names(admixture.prop) <- X.name
  admixture.CI <- CI[, 1:ncol(X)]
  admixture.SD <- SD[1:ncol(X)]
  colnames(admixture.CI) <- colnames(admixture.SD) <- X.name

  pie.dat <- data.frame(
    Group = factor(names(admixture.prop), levels = names(admixture.prop)),
    Prop = admixture.prop,
    do.call("rbind", admixture.CI)
  ) %>% tibble()
  print(pie.dat)
  label.prop <- rev(sapply(1:nrow(pie.dat), function(i) paste0(paste0(pie.dat$Group[i], "\n"), round(100 * pie.dat$Prop[i], 2), "%")))

  pie.plt <- ggplot(data = pie.dat, mapping = aes(x = "Content", y = Prop, fill = Group)) +
    geom_bar(stat = "identity", position = "stack", width = 1) +
    theme_bw() +
    theme(
      panel.border = element_blank(),
      panel.grid = element_blank(),
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      axis.text.x = element_blank(),
      axis.text.y = element_blank(),
      axis.ticks = element_blank(),
      legend.position = "none",
      legend.title = element_blank()
    ) +
    coord_polar(theta = "y", start = 0) +
    scale_fill_manual(values = col) +
    geom_text(aes(y = rev(Prop) / 2 + c(0, cumsum(rev(Prop))[-length(Prop)]), x = sum(Prop) / 0.9, label = label.prop), size = 3.8, face = "bold")

  bar.plt <- ggplot(pie.dat, aes(x = reorder(Group, Prop), y = Prop, fill = Group), col = "black") +
    theme_bw() +
    geom_errorbar(aes(ymin = X2.5., ymax = X97.5., col = Group), width = 0, size = 7) +
    geom_errorbar(aes(ymin = Prop - 0.0025, ymax = Prop + 0.0025), col = "black", width = 0, size = 7) +
    theme(
      panel.grid = element_blank(),
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      axis.text.x = element_text(size = 10, face = "bold"),
      axis.text.y = element_text(size = 10, face = "bold"),
      legend.position = "none"
    ) +
    scale_fill_manual(values = col) +
    scale_colour_manual(values = col) +
    coord_flip()
  box.dat <- burn.left.scale[, 1:n.beta] %>%
    as_tibble() %>%
    rename_all(.funs = function(i) X.name) %>%
    melt()
  pair.list <- lapply(combn(names(admixture.prop[order(admixture.prop)]), 2) %>% as_tibble(), function(i) i)
  sig.pos <- rev(sapply(1:n.beta, function(i) 1 - 0.07 * i))
  box.plt <- ggplot(box.dat, aes(x = reorder(variable, value), y = value, fill = variable)) +
    geom_boxplot(outlier.colour = NA, size = 0.8, width = 0.5, angle = 90) +
    theme_bw() +
    stat_boxplot(geom = "errorbar", aes(ymin = quantile(value, 0.025), ymax = quantile(value, 0.975)), width = 0.3, size = 0.8) +
    theme(
      panel.grid = element_blank(),
      axis.title.x = element_blank(),
      axis.title.y = element_blank(),
      axis.text.x = element_text(size = 12, face = "bold", colour = "black"),
      axis.text.y = element_text(size = 12, face = "bold", colour = "black"),
      legend.position = "none",
      panel.border = element_rect(fill = NA, color = "black", size = 1.1, linetype = "solid")
    ) +
    scale_fill_manual(values = col) +
    scale_colour_manual(values = col) +
    coord_flip()
  return(list(admixture.prop = admixture.prop, admixture.CI = admixture.CI, admixture.SD = admixture.SD, burn.left.scale = burn.left.scale[, 1:n.beta], pie.plt = pie.plt, bar.plt = bar.plt, box.plt = box.plt, pie.dat = pie.dat))
}
